// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xgas_nn.h"

extern XGas_nn_Config XGas_nn_ConfigTable[];

XGas_nn_Config *XGas_nn_LookupConfig(u16 DeviceId) {
	XGas_nn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGAS_NN_NUM_INSTANCES; Index++) {
		if (XGas_nn_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGas_nn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGas_nn_Initialize(XGas_nn *InstancePtr, u16 DeviceId) {
	XGas_nn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGas_nn_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGas_nn_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

