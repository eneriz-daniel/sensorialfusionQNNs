// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xgas_nn.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGas_nn_CfgInitialize(XGas_nn *InstancePtr, XGas_nn_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

u32 XGas_nn_Get_in_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_BASE);
}

u32 XGas_nn_Get_in_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_HIGH);
}

u32 XGas_nn_Get_in_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_IN_V_HIGH - XGAS_NN_AXILITES_ADDR_IN_V_BASE + 1);
}

u32 XGas_nn_Get_in_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_IN_V;
}

u32 XGas_nn_Get_in_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_IN_V;
}

u32 XGas_nn_Write_in_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_IN_V_HIGH - XGAS_NN_AXILITES_ADDR_IN_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_in_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_IN_V_HIGH - XGAS_NN_AXILITES_ADDR_IN_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_in_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_IN_V_HIGH - XGAS_NN_AXILITES_ADDR_IN_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_in_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_IN_V_HIGH - XGAS_NN_AXILITES_ADDR_IN_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_IN_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_w01_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_BASE);
}

u32 XGas_nn_Get_w01_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_HIGH);
}

u32 XGas_nn_Get_w01_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_W01_V_HIGH - XGAS_NN_AXILITES_ADDR_W01_V_BASE + 1);
}

u32 XGas_nn_Get_w01_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_W01_V;
}

u32 XGas_nn_Get_w01_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_W01_V;
}

u32 XGas_nn_Write_w01_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W01_V_HIGH - XGAS_NN_AXILITES_ADDR_W01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w01_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W01_V_HIGH - XGAS_NN_AXILITES_ADDR_W01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_w01_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W01_V_HIGH - XGAS_NN_AXILITES_ADDR_W01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w01_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W01_V_HIGH - XGAS_NN_AXILITES_ADDR_W01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W01_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_b01_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_BASE);
}

u32 XGas_nn_Get_b01_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_HIGH);
}

u32 XGas_nn_Get_b01_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_B01_V_HIGH - XGAS_NN_AXILITES_ADDR_B01_V_BASE + 1);
}

u32 XGas_nn_Get_b01_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_B01_V;
}

u32 XGas_nn_Get_b01_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_B01_V;
}

u32 XGas_nn_Write_b01_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B01_V_HIGH - XGAS_NN_AXILITES_ADDR_B01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b01_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B01_V_HIGH - XGAS_NN_AXILITES_ADDR_B01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_b01_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B01_V_HIGH - XGAS_NN_AXILITES_ADDR_B01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b01_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B01_V_HIGH - XGAS_NN_AXILITES_ADDR_B01_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B01_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_w12_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_BASE);
}

u32 XGas_nn_Get_w12_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_HIGH);
}

u32 XGas_nn_Get_w12_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_W12_V_HIGH - XGAS_NN_AXILITES_ADDR_W12_V_BASE + 1);
}

u32 XGas_nn_Get_w12_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_W12_V;
}

u32 XGas_nn_Get_w12_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_W12_V;
}

u32 XGas_nn_Write_w12_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W12_V_HIGH - XGAS_NN_AXILITES_ADDR_W12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w12_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W12_V_HIGH - XGAS_NN_AXILITES_ADDR_W12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_w12_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W12_V_HIGH - XGAS_NN_AXILITES_ADDR_W12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w12_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W12_V_HIGH - XGAS_NN_AXILITES_ADDR_W12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W12_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_b12_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_BASE);
}

u32 XGas_nn_Get_b12_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_HIGH);
}

u32 XGas_nn_Get_b12_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_B12_V_HIGH - XGAS_NN_AXILITES_ADDR_B12_V_BASE + 1);
}

u32 XGas_nn_Get_b12_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_B12_V;
}

u32 XGas_nn_Get_b12_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_B12_V;
}

u32 XGas_nn_Write_b12_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B12_V_HIGH - XGAS_NN_AXILITES_ADDR_B12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b12_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B12_V_HIGH - XGAS_NN_AXILITES_ADDR_B12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_b12_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B12_V_HIGH - XGAS_NN_AXILITES_ADDR_B12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b12_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B12_V_HIGH - XGAS_NN_AXILITES_ADDR_B12_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B12_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_w23_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_BASE);
}

u32 XGas_nn_Get_w23_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_HIGH);
}

u32 XGas_nn_Get_w23_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_W23_V_HIGH - XGAS_NN_AXILITES_ADDR_W23_V_BASE + 1);
}

u32 XGas_nn_Get_w23_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_W23_V;
}

u32 XGas_nn_Get_w23_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_W23_V;
}

u32 XGas_nn_Write_w23_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W23_V_HIGH - XGAS_NN_AXILITES_ADDR_W23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w23_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_W23_V_HIGH - XGAS_NN_AXILITES_ADDR_W23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_w23_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W23_V_HIGH - XGAS_NN_AXILITES_ADDR_W23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_w23_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_W23_V_HIGH - XGAS_NN_AXILITES_ADDR_W23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_W23_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_b23_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_BASE);
}

u32 XGas_nn_Get_b23_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_HIGH);
}

u32 XGas_nn_Get_b23_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_B23_V_HIGH - XGAS_NN_AXILITES_ADDR_B23_V_BASE + 1);
}

u32 XGas_nn_Get_b23_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_B23_V;
}

u32 XGas_nn_Get_b23_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_B23_V;
}

u32 XGas_nn_Write_b23_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B23_V_HIGH - XGAS_NN_AXILITES_ADDR_B23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b23_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_B23_V_HIGH - XGAS_NN_AXILITES_ADDR_B23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_b23_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B23_V_HIGH - XGAS_NN_AXILITES_ADDR_B23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_b23_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_B23_V_HIGH - XGAS_NN_AXILITES_ADDR_B23_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_B23_V_BASE + offset + i);
    }
    return length;
}

u32 XGas_nn_Get_out_V_BaseAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_BASE);
}

u32 XGas_nn_Get_out_V_HighAddress(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_HIGH);
}

u32 XGas_nn_Get_out_V_TotalBytes(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGAS_NN_AXILITES_ADDR_OUT_V_HIGH - XGAS_NN_AXILITES_ADDR_OUT_V_BASE + 1);
}

u32 XGas_nn_Get_out_V_BitWidth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_WIDTH_OUT_V;
}

u32 XGas_nn_Get_out_V_Depth(XGas_nn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGAS_NN_AXILITES_DEPTH_OUT_V;
}

u32 XGas_nn_Write_out_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_OUT_V_HIGH - XGAS_NN_AXILITES_ADDR_OUT_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_out_V_Words(XGas_nn *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGAS_NN_AXILITES_ADDR_OUT_V_HIGH - XGAS_NN_AXILITES_ADDR_OUT_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGas_nn_Write_out_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_OUT_V_HIGH - XGAS_NN_AXILITES_ADDR_OUT_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGas_nn_Read_out_V_Bytes(XGas_nn *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGAS_NN_AXILITES_ADDR_OUT_V_HIGH - XGAS_NN_AXILITES_ADDR_OUT_V_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XGAS_NN_AXILITES_ADDR_OUT_V_BASE + offset + i);
    }
    return length;
}

