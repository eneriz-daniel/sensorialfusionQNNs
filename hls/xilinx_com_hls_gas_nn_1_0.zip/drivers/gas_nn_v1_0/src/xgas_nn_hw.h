// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x0020 ~
// 0x003f : Memory 'in_V' (16 * 12b)
//          Word n : bit [11: 0] - in_V[2n]
//                   bit [27:16] - in_V[2n+1]
//                   others      - reserved
// 0x0400 ~
// 0x07ff : Memory 'w01_V' (512 * 12b)
//          Word n : bit [11: 0] - w01_V[2n]
//                   bit [27:16] - w01_V[2n+1]
//                   others      - reserved
// 0x0800 ~
// 0x083f : Memory 'b01_V' (32 * 12b)
//          Word n : bit [11: 0] - b01_V[2n]
//                   bit [27:16] - b01_V[2n+1]
//                   others      - reserved
// 0x0c00 ~
// 0x0fff : Memory 'w12_V' (384 * 12b)
//          Word n : bit [11: 0] - w12_V[2n]
//                   bit [27:16] - w12_V[2n+1]
//                   others      - reserved
// 0x1000 ~
// 0x101f : Memory 'b12_V' (12 * 12b)
//          Word n : bit [11: 0] - b12_V[2n]
//                   bit [27:16] - b12_V[2n+1]
//                   others      - reserved
// 0x1040 ~
// 0x107f : Memory 'w23_V' (24 * 12b)
//          Word n : bit [11: 0] - w23_V[2n]
//                   bit [27:16] - w23_V[2n+1]
//                   others      - reserved
// 0x1080 ~
// 0x1087 : Memory 'b23_V' (2 * 12b)
//          Word n : bit [11: 0] - b23_V[2n]
//                   bit [27:16] - b23_V[2n+1]
//                   others      - reserved
// 0x1088 ~
// 0x108f : Memory 'out_V' (2 * 12b)
//          Word n : bit [11: 0] - out_V[2n]
//                   bit [27:16] - out_V[2n+1]
//                   others      - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XGAS_NN_AXILITES_ADDR_IN_V_BASE  0x0020
#define XGAS_NN_AXILITES_ADDR_IN_V_HIGH  0x003f
#define XGAS_NN_AXILITES_WIDTH_IN_V      12
#define XGAS_NN_AXILITES_DEPTH_IN_V      16
#define XGAS_NN_AXILITES_ADDR_W01_V_BASE 0x0400
#define XGAS_NN_AXILITES_ADDR_W01_V_HIGH 0x07ff
#define XGAS_NN_AXILITES_WIDTH_W01_V     12
#define XGAS_NN_AXILITES_DEPTH_W01_V     512
#define XGAS_NN_AXILITES_ADDR_B01_V_BASE 0x0800
#define XGAS_NN_AXILITES_ADDR_B01_V_HIGH 0x083f
#define XGAS_NN_AXILITES_WIDTH_B01_V     12
#define XGAS_NN_AXILITES_DEPTH_B01_V     32
#define XGAS_NN_AXILITES_ADDR_W12_V_BASE 0x0c00
#define XGAS_NN_AXILITES_ADDR_W12_V_HIGH 0x0fff
#define XGAS_NN_AXILITES_WIDTH_W12_V     12
#define XGAS_NN_AXILITES_DEPTH_W12_V     384
#define XGAS_NN_AXILITES_ADDR_B12_V_BASE 0x1000
#define XGAS_NN_AXILITES_ADDR_B12_V_HIGH 0x101f
#define XGAS_NN_AXILITES_WIDTH_B12_V     12
#define XGAS_NN_AXILITES_DEPTH_B12_V     12
#define XGAS_NN_AXILITES_ADDR_W23_V_BASE 0x1040
#define XGAS_NN_AXILITES_ADDR_W23_V_HIGH 0x107f
#define XGAS_NN_AXILITES_WIDTH_W23_V     12
#define XGAS_NN_AXILITES_DEPTH_W23_V     24
#define XGAS_NN_AXILITES_ADDR_B23_V_BASE 0x1080
#define XGAS_NN_AXILITES_ADDR_B23_V_HIGH 0x1087
#define XGAS_NN_AXILITES_WIDTH_B23_V     12
#define XGAS_NN_AXILITES_DEPTH_B23_V     2
#define XGAS_NN_AXILITES_ADDR_OUT_V_BASE 0x1088
#define XGAS_NN_AXILITES_ADDR_OUT_V_HIGH 0x108f
#define XGAS_NN_AXILITES_WIDTH_OUT_V     12
#define XGAS_NN_AXILITES_DEPTH_OUT_V     2

